//客户业务后台请求域名，用于获取IM信息
var GetTestLoginInfoUrl = "https://room.qcloud.com";

/**
 * 通过一个 http 接口获取腾讯云提供的 TRTC 测试账号，该接口仅用于测试和体验目的，正式上线时请替换为自己的腾讯云账号。
 */
function getLoginInfo(options) {
  wx.login({
    success: function (res) {
      if (res.code) {
        console.log('获取code成功',res.code);
        options.code = res.code;
        proto_getLoginInfo(options);
        // 获取用户信息,该接口微信有调整，如果需要使用，请查看https://developers.weixin.qq.com/miniprogram/dev/api/open.html
        // wx.getUserInfo({
        //   withCredentials: false,
        //   success: function (ret) {
        //     options.userName = ret.userInfo.nickName;
        //   },
        //   fail: function() {
        //     proto_getLoginInfo(options);
        //   }
        // });
      } else {
        console.log('获取用户登录态失败！' + res.errMsg);
        options.fail && options.fail({
          errCode: -1,
          errMsg: '获取用户登录态失败，请退出重试'
        });
      }
    },
    fail: function () {
      console.log('获取用户登录态失败！' + res.errMsg);
      if (ret.errMsg == 'request:fail timeout') {
        var errCode = -1;
        var errMsg = '网络请求超时，请检查网络状态';
      }
      options.fail && options.fail({
        errCode: errCode || -1,
        errMsg: errMsg || '获取用户登录态失败，请退出重试'
      });
    }
  });
}

// 调用后台获取登录信息接口
function proto_getLoginInfo(options) {
  wx.request({
    url: GetTestLoginInfoUrl + '/weapp/utils/get_login_info',
    data: { userIDPrefix: 'weixin', code: options.code },
    method: 'GET',
    header: {
      'content-type': 'application/json' // 默认值
    },
    success: function (ret) {
      if (ret.data.code) {
        console.log('获取登录信息失败，调试期间请点击右上角三个点按钮，选择打开调试');
        options.fail && options.fail({
          errCode: ret.data.code,
          errMsg: ret.data.message + '[' + ret.data.code + ']'
        });
        return;
      }
      console.log('获取IM登录信息成功: ', ret.data);
      options.success && options.success({
        data: {
          code: 0, message: '请求成功', userID: "admin", sdkAppID: '1400237283', accType: "18647", userSig: "eJxlz1FvgjAQwPF3PgXpK8vSgh3WZA*IqDOIVUey8ULQVrgYkJTqhmbffRkzGcnu9fe-XO5mmKaJXsPtY7bfn86VTnVbS2SOTITRwx-WNYg006mjxD*UnzUomWYHLVWHhFJqY9xvQMhKwwHuRSZKqHrciGPa3fjdH2BsO649dPoJ5B0ug9h-mZJifBnnXIcb9cbW-sJf58X8-NFwUuzaqzc5ymTLrWixunoQeK3LpxZd5sVuBX7Cw5h570lZt8wKEz6LqF8G8SzK48nce*6d1FDK*0NPA4KZO2Q9vUjVwKnqAhsTSmwH-wwyvoxv8zZchA__"}
      });
    },
    fail: function (ret) {
      console.log('获取IM登录信息失败: ', ret);
      if (ret.errMsg == 'request:fail timeout') {
        var errCode = -1;
        var errMsg = '网络请求超时，请检查网络状态';
      }
      options.fail && options.fail({
        errCode: errCode || -1,
        errMsg: errMsg || '获取登录信息失败，调试期间请点击右上角三个点按钮，选择打开调试'
      });
    }
  });
}

module.exports = {
  getLoginInfo: getLoginInfo
};