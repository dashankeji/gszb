//获取应用实例
var webim = require('../../../utils/webim_wx.js');
var webimhandler = require('../../../utils/webim_handler.js');


global.webim = webim;

const app = getApp()

Page({
  component: null,
  data: {
    userName: '',
    roomID: '',
    roomName: '',
    pureAudio: false,
    role: 'audience',
    showLiveRoom: false,
    rooms: [],
    comment: [],
    linked: false,
    debug: false,
    frontCamera: true,
    inputMsg: [],
    muted: false,
    toview: '',
    beauty: 5,
    shouldExit: false,
    phoneNum: '',
    headerHeight: app.globalData.headerHeight,
    statusBarHeight: app.globalData.statusBarHeight,
    FullScreenFlag: false,
    /*云通信*/
    identifier: '', // 当前用户身份标识，必选
    userSig: '', // 当前用户签名，必选
    nickName: '', // 当前用户昵称，选填
    avChatRoomId: 0, // 群ID, 必选
    motto: 'Hello World',
    msgs: [],
    msgContent: "",
    msgContentTwo: "",
    scrollTop: 0,
    uid: null,
    sendFlag: false
  },

  onLoad: function (options) {

    var self = this;
    console.log("--> onLoad: ", options)
    var role = options.type == 'create' ? 'anchor' : 'audience';

    if (role == 'audience') {
      

      self.setData({
        roomID: options.roomID,
        roomName: options.roomName,
        userName: options.userName,
        identifier: options.userName,
        role: role,
        showLiveRoom: true,
        uid: app.globalData.uid,
        avChatRoomId: options.roomID
      }, function () {
        self.start(); 
     //   self.initIM(options.sdkAppID, options.userSig, options.userID);
      })
    } else {
      self.setData({
        roomName: options.roomName,
        userName: options.userName,
        avChatRoomId: 'room_' + app.globalData.uid,
        roomID: 'room_' + app.globalData.uid,
        identifier: options.userName,
        pureAudio: JSON.parse(options.pureAudio),
        uid: app.globalData.uid,
        role: role,
        showLiveRoom: true
      }, function () {
        console.log('======> page data: ', self.data)
        self.start();
       // self.initIM(options.sdkAppID, options.userSig, options.userID);
      })
    }
  },

  onReady: function () {
    var self = this;
    wx.setNavigationBarTitle({
      title: self.data.roomName
    })
  },

  onRoomEvent: function (e) {
    var self = this;
    var args = e.detail;
    console.log('onRoomEvent', args)
    switch (args.tag) {
      case 'roomClosed': {
        wx.showModal({
          content: `房间已解散`,
          showCancel: false,
          complete: () => {
            wx.navigateBack({ delta: 1 })
          }
        });
        break;
      }
      case 'error': {
        wx.showToast({
          title: `${args.detail}[${args.code}]`,
          icon: 'none',
          duration: 1500
        })
        if (args.code == 5000) {
          this.data.shouldExit = true;
        } else {
          console.error("收到error:", args)
          if (args.code != -9004) {
            setTimeout(() => {
              wx.navigateBack({ delta: 1 })
            }, 1500)
          } else {
            self.setData({
              linked: false,
              phoneNum: ''
            })
          }
        }
        break;
      }
      case 'linkOn': { // 连麦连上
        self.setData({
          linked: true,
          phoneNum: ''
        })
        break;
      }
      case 'linkOut': { //连麦断开
        self.setData({
          linked: false,
          phoneNum: ''
        })
        break;
      }
      case 'recvTextMsg': {
        console.log('收到消息:', e.detail.detail);
        var msg = e.detail.detail;
        self.data.comment.push({
          content: msg.message,
          name: msg.userName,
          userId: msg.userID,
          userAvatar: msg.userAvatar,
          time: msg.time,
          roomID: msg.roomID
        });
        
        var len = self.data.comment.length;

        if (len > 3) {
          self.setData({
            scrollTop: len * 400
          })
        };

        self.setData({
          comment: self.data.comment,
          toview: ''
        });
        // 滚动条置底
       /* self.setData({
          toview: 'scroll-bottom'
        });*/
        break;
      }
      case 'privceRecvTextMsg': {
        console.log('收到私信消息:', e.detail.detail);
        var msg = e.detail.detail;
        self.data.comment.push({
          content: msg.message,
          name: msg.userName + '(私信)',
          userId: msg.userID,
          userAvatar: msg.userAvatar,
          time: msg.time,
          roomID: msg.roomID
        });

        var len = self.data.comment.length;
        if (len > 3) {
          self.setData({
            scrollTop: len * 400
          })
        };

        self.setData({
          comment: self.data.comment,
          toview: ''
        });
        // 滚动条置底
        /* self.setData({
           toview: 'scroll-bottom'
         });*/
        break;
      }
      case 'requestJoinAnchor': { //收到连麦请求
        var jioner = args.detail;
        var showBeginTime = Math.round(Date.now());
        wx.showModal({
          content: `${jioner.userName} 请求连麦`,
          cancelText: '拒绝',
          confirmText: '接受',
          success: function (sm) {
            var timeLapse = Math.round(Date.now()) - showBeginTime;
            if (timeLapse < 10000) {
              if (sm.confirm) {
                console.log('用户点击同意')
                self.component && self.component.respondJoinAnchor(true, jioner);
              } else if (sm.cancel) {
                console.log('用户点击取消')
                self.component && self.component.respondJoinAnchor(false, jioner);
              }
            } else {
              wx.showToast({
                title: '连麦超时',
              })
            }
          }
        })
        break;
      }
      default: {
        console.log('onRoomEvent default: ', e)
        break;
      }
    }
  },

  kickoutJoinAnchor: function (e) {   //  踢人（本来是踢连麦的，但这里把连麦隐藏,然后在mlvbliverommview.js里的 quitLink方法里的 加了）
    
    if (!e.currentTarget.dataset.userid) {
      wx.showToast({
        title: '获取信息失败'
      });
      return;
    };
    var self = this;
        wx.showModal({
          title: '踢人',
          content: '是否把该用户踢出房间',
          success(res) {
            if (res.confirm) {
              self.component.kickoutJoinAnchor(e, function (msg) {
                wx.showToast({
                  title: msg
                });
              });
            } else if (res.cancel) {
              console.log('用户点击取消')
            };
    
          }
        });
  },

  forbidSendMsg: function(e){     //  禁言
    var userId = e.currentTarget.dataset.userid;
    if (!userId) {
      wx.showToast({
        title: '获取信息失败'
      });
      return;
    };
    var self = this;
    wx.showModal({
      title: '禁言',
      content: '是否把' + e.currentTarget.dataset.username +'禁言',
      success(res) {
        if (res.confirm) {
          
          wx.showActionSheet({
            itemList: ['1分钟', '3分钟', '10分钟', '30分钟', '60分钟','取消禁言'],
            success(res) {
               var tabIndex = res.tapIndex;
               var time = '';

               var ShutUpTime = 1;
               switch(tabIndex){
                  case 0:
                       ShutUpTime = 1 * 60;
                       time = '1分钟';
                       break;
                  case 1:
                       ShutUpTime = 3 * 60;
                       time = '3分钟'; 
                       break;
                  case 2:
                       ShutUpTime = 10 * 60;
                       time = '10分钟';
                       break;
                  case 3:
                       ShutUpTime = 30 * 60;
                       time = '30分钟';
                       break;
                  case 4:
                       ShutUpTime = 60 * 60;
                       time = '60分钟';
                       break;
                  case 5:
                    ShutUpTime = 0;
                    time = '0分钟';
                    break;                       
               };
              var options = {};
              options.GroupId = self.data.roomID;
              options.Members_Account = [userId];
              options.ShutUpTime = ShutUpTime;
              self.component.forbidSendMsg(options, function () {
                wx.showToast({
                  title: '禁言成功',
                });
                self.component.sendTextMsg(e.currentTarget.dataset.username + '被禁言' + time, function () { });
              }, function (e) {
                wx.showToast({
                  title: '禁言失败',
                });
              });
            },
            fail(res) {
              console.log('用户选择禁言时间点击取消: ' + res.errMsg)
            }
          });

        } else if (res.cancel) {
          console.log('用户确认禁言时点击取消')
        };

      }
    });  // wx.showModal 结尾

  },

  NoForbidSendMsg: function(e){   //  取消禁言
    var userId = e.currentTarget.dataset.userid;
    if (!userId) {
      wx.showToast({
        title: '获取信息失败'
      });
      return;
    };
    var self = this;
    wx.showModal({
      title: '禁言',
      content: '是否取消该' + e.currentTarget.dataset.username +'禁言',
      success(res) {
        if (res.confirm) {
          var options = {};
          options.GroupId = self.data.roomID;
          options.Members_Account = [userId];
          options.ShutUpTime = 0;
          self.component.forbidSendMsg(options, function () {
            wx.showToast({
              title: '取消禁言成功',
            });
            self.component.sendTextMsg(e.currentTarget.dataset.username + '取消禁言',function(){});
          }, function (e) {
            wx.showToast({
              title: '取消禁言失败',
            });
          });

        } else if (res.cancel) {
          console.log('用户点击取消')
        };

      }
    });
  },

  sendPrivateChat: function (userid,text,callback) {  //  发送私信
    var userId = userid;
    if (!userId) {
      wx.showToast({
        title: '获取信息失败'
      });
      return;
    };

    var self = this;

    self.component.sendPrivateChat(userId, text, callback);
  },

  start: function () {
    var self = this;
    self.component = self.selectComponent("#id_liveroom")
    console.log('self.component: ', self.component)
    console.log('self:', self);
    self.component.start();
  },
  onLinkClick: function () {
    var self = this;
    self.component && self.component.requestJoinAnchor();
    self.setData({
      phoneNum: 'phone-1'
    })
    self.setInternal();
  },
  setInternal: function () {
    var self = this;
    setTimeout(() => {
      if (!self.data.phoneNum) {
        return;
      }

      var curPhoneNum = '';
      switch (self.data.phoneNum) {
        case 'phone-1':
          curPhoneNum = 'phone-2';
          break;
        case 'phone-2':
          curPhoneNum = 'phone-3';
          break;
        case 'phone-3':
          curPhoneNum = 'phone-1';
          break;
        default:
          break;
      }
      self.setData({
        phoneNum: curPhoneNum
      })
      self.setInternal();
    }, 500);
  },
  goRoom: function (e) {
    var self = this;
    var index = parseInt(e.currentTarget.dataset.index);
    var roomID = self.data.rooms[index].roomID;
    self.setData({
      roomID: roomID
    })
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    if (this.data.shouldExit) {
      wx.showModal({
        title: '提示',
        content: "收到退房通知",
        showCancel: false,
        complete: function () {
          wx.navigateBack({ delta: 1 });
        }
      });
    }
    var self = this;
    self.component && self.component.resume();
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
    var self = this;
    self.component && self.component.pause();

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
    var self = this;
    
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
    return {
      // title: '多人音视频',
      // path: '/pages/multiroom/roomlist/roomlist',
      path: '/pages/home-page/main',
      imageUrl: 'https://mc.qcloudimg.com/static/img/dacf9205fe088ec2fef6f0b781c92510/share.png'
    }
  },

  showFullScreen: function() {
     var self = this;
     
     self.setData({
       FullScreenFlag: !self.data.FullScreenFlag
     });
  },

  showLog: function () {
    var self = this;
    self.setData({
      debug: !self.data.debug
    })
  },
  changeMute: function () {
    var self = this;
    self.setData({
      muted: !self.data.muted
    })
  },
  setBeauty: function () {
    var self = this;
    self.setData({
      beauty: self.data.beauty == 5 ? 0 : 5
    })
  },
  changeCamera: function () {
    var self = this;
    self.component && self.component.switchCamera();
    self.setData({
      frontCamera: !self.data.frontCamera
    })
  },
  bindInputMsg: function (e) {
    this.data.inputMsg = e.detail.value;
  },
  onBack: function () {
    wx.navigateBack({
      delta: 1
    });
  },

  /* 云通讯 */
  clearInput: function () {
    this.setData({
      msgContent: ""
    })
  },
  clearInputTwo: function () {
    this.setData({
      msgContentTwo: ""
    })
  },
  bindconfirm: function(e){
    var that = this;

    
    var content = e.detail.value;
    if (!content.replace(/^\s*|\s*$/g, '')) return;


    /* webimhandler.onSendMsg(content, function () {
       that.clearInput();
     }) */
    that.component.sendTextMsg(content, function () {

      that.clearInput();
    });
  },
  bindblur: function (e) {
    var that = this;

    that.data.msgContent = e.detail.value;
  },
  bindinput: function(e) {

    this.data.msgContent = e.detail.value;
  },
  sendConfirm: function () {
    var that = this;
   
    var content = that.data.msgContent;


    if (!content.replace(/^\s*|\s*$/g, '')) return;

 
   /* webimhandler.onSendMsg(content, function () {
      that.clearInput();
    }) */
    that.component.sendTextMsg(content, function () {
   
      that.clearInput();
    });
  },

  bindConfirmTwo: function (e) {

    var that = this;
    var content = e.detail.value;
    if (!content.replace(/^\s*|\s*$/g, '')) return;
     
    that.sendPrivateChat(e.currentTarget.dataset.userid,content,function () {
      that.clearInputTwo();
    });
  },

  bindTap: function () {
    this.component.sendGroupLoveMsg();
  },


  receiveMsgs: function (data) {
    console.log('receiveMsgs', data);
    var msgs = this.data.msgs || [];
    var that = this;
    msgs.push(data);
    //最多展示10条信息
    if (msgs.length > 3) {
      that.setData({
         scrollTop: that.data.scrollTop + 150
       })

    }

    that.setData({
      msgs: msgs
    })
  },
  scroll: function(e){
     console.log(e)
  },
  initIM: function (sdkAppId,userSig,userId) {    // 腾讯云直播里面配置了，这个废弃了

    var that = this;
    var avChatRoomId = that.data.avChatRoomId;

    webimhandler.init({
      accountMode: 0,//帐号模式，0-表示独立模式，1-表示托管模式(已停用，仅作为演示)
      accountType: 1, // 已废弃
      sdkAppID: sdkAppId,
      avChatRoomId: avChatRoomId, //默认房间群ID，群类型必须是直播聊天室（AVChatRoom）
      selType: webim.SESSION_TYPE.GROUP,
      selToID: avChatRoomId,
      selSess: null //当前聊天会话
    });
    //当前用户身份
    var loginInfo = {
      'sdkAppID': sdkAppId, //用户所属应用id,必填
      'appIDAt3rd': sdkAppId, //用户所属应用id，必填
      'accountType': 1, // 已废弃
      'identifier': userId, //当前用户ID,必须是否字符串类型，选填
      'identifierNick': that.data.userName || '', //当前用户昵称，选填
      'userSig': userSig, //当前用户身份凭证，必须是字符串类型，选填
    };

    //监听（多终端同步）群系统消息方法，方法都定义在demo_group_notice.js文件中
    var onGroupSystemNotifys = {
      "5": webimhandler.onDestoryGroupNotify, //群被解散(全员接收)
      "11": webimhandler.onRevokeGroupNotify, //群已被回收(全员接收)
      "255": webimhandler.onCustomGroupNotify //用户自定义通知(默认全员接收) 
    };

    //监听连接状态回调变化事件
    var onConnNotify = function (resp) {
      switch (resp.ErrorCode) {
        case webim.CONNECTION_STATUS.ON:
          //webim.Log.warn('连接状态正常...');
          break;
        case webim.CONNECTION_STATUS.OFF:
          webim.Log.warn('连接已断开，无法收到新消息，请检查下你的网络是否正常');
          break;
        default:
          webim.Log.error('未知连接状态,status=' + resp.ErrorCode);
          break;
      }
    };


    //监听事件
    var listeners = {
      "onConnNotify": webimhandler.onConnNotify, //选填
      "onBigGroupMsgNotify": function (msg) {
        webimhandler.onBigGroupMsgNotify(msg, function (msgs) {
  
          that.receiveMsgs(msgs);
        })
      }, //监听新消息(大群)事件，必填
      "onMsgNotify": webimhandler.onMsgNotify, //监听新消息(私聊(包括普通消息和全员推送消息)，普通群(非直播聊天室)消息)事件，必填
      "onGroupSystemNotifys": webimhandler.onGroupSystemNotifys, //监听（多终端同步）群系统消息事件，必填
      "onGroupInfoChangeNotify": webimhandler.onGroupInfoChangeNotify //监听群资料变化事件，选填
    };

    //其他对象，选填
    var options = {
      'isAccessFormalEnv': true, //是否访问正式环境，默认访问正式，选填
      'isLogOn': true //是否开启控制台打印日志,默认开启，选填
    };

    webimhandler.sdkLogin(loginInfo, listeners, options, avChatRoomId);
  },
})
