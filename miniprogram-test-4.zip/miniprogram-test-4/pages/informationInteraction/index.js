
/*var part_urls = {};
var videoPage;
var pageArr = new Array()*/
import qqVideo from "../../utils/qqVideo.js"
var app = getApp();

Page({
  data: {
    videos: [],   //  装请求的数据
    videUrls: [], //  装请求数据的一部分
    videoJson: {
      index: -1,
      dom: null
    },
    page: 2,
    rows: 3,
    hidden: false
  },
  onLoad: function () {


    var that = this;
    that.getVideosReq();

  },
  getVideosReq: function () {
    var header = {
      'content-type': 'application/x-www-form-urlencoded',
    };
    var that = this;

    wx.request({
      url: app.globalData.url + '/routine/auth_api/getshortvideo?uid=' + app.globalData.uid ,
      data: {
        xiaoben: true,
        page: 1,
        rows: 3
      },
      method: 'GET',
      header: header,
      success: function (res) {

        that.data.videos = res.data.data.items;

        for (var i = 0; i < that.data.videos.length; i++) {
          that.playVideo(that.data.videos[i].url, that.data.videos[i].title);
        }
      }
    });
  },
  playVideo: function (vid, title) {


    var videoPage = 1;
    var pageArr = new Array();
    var part_urls = {};
    var that = this;

    qqVideo.getVideoes(vid).then(function (response) {

      for (var i = 1; i < response.length + 1; i++) {
        var indexStr = 'index' + (i)
        pageArr.push(i);
        part_urls[indexStr] = response[i - 1];
      };

      //console.log(response[0]);

      that.data.videUrls.push({ url: response[0], title: title });
      that.setData({
        videUrls: that.data.videUrls,
      });
    });

  },
  playStart: function (e) {

    var that = this;
    var eIndex = e.currentTarget.dataset.index;
    var dom = that.data.videoJson.dom;
    var videoJsonIndex = "videoJson.index";
    var videoJsonDom = "videoJson.dom";
     
    if (that.data.videoJson.index == eIndex) return;

    if (dom != null) {
      dom.pause();
    };


    that.setData({
      [videoJsonIndex]: eIndex,
      [videoJsonDom]: wx.createVideoContext(e.currentTarget.id)
    });
  },
  // 因为视频超过10分钟之后，会分段，所以当视频为多段的时候，
  // 自动播放下一段视频
  playEnd: function () {

    /* if (videoPage >= parseInt(pageArr.length)) {
       // part_urls = {};
       videoPage = 1;
       this.videoContext.exitFullScreen
     } else {
       videoPage++;
       var index = 'index' + videoPage;
       this.setData({
         videUrl: ''
       });
       this.setData({
         videUrl: part_urls[index]
       });
     }*/
  },
  onReady: function () {
 
    // 页面渲染完成
    // this.videoContext = wx.createVideoContext('myVideo')
  },
  onShow: function () {
    // 页面显示
  },
  onHide: function () {
    // 页面隐藏
    var that = this;
    if (that.data.videoJson.dom != null) {
      that.data.videoJson.dom.pause();
    };

  },
  onUnload: function () {
    // 页面关闭
  },
    /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
    var that = this;
    var limit = that.data.rows;

    if (that.data.hidden) return;

    var offset = that.data.page++;

    that.setData({
      hidden: true,
    });

    wx.request({
      url: app.globalData.url + '/routine/auth_api/getshortvideo?uid=' + app.globalData.uid ,
      data: {
        xiaoben: true,
        page: offset,
        rows: limit
      },
      method: 'GET',
      success: function (res) {
        if (res.data.data.items.length < 1) {
          --that.data.page;
          wx.showToast({
            title: '没有更多的视频了',
            icon: 'none',
            duration: 2000
          })
        } else {
          
          that.data.videos = res.data.data.items;

          for (var i = 0; i < that.data.videos.length; i++) {
            that.playVideo(that.data.videos[i].url, that.data.videos[i].title);
          }
         
        };
        that.setData({
          hidden: false,
          TabDatas: that.data.TabDatas
        });
      },
      fail: function (res) {
        console.log('submit fail');
      },
      complete: function (res) {
        console.log('submit complete');
      }
    })
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})