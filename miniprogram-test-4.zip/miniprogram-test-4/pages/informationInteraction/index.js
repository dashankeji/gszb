
/*var part_urls = {};
var videoPage;
var pageArr = new Array()*/
import qqVideo from "../../utils/qqVideo.js"
var app = getApp();

Page({
  data: {
    videos: [],   //  装请求的数据
    videUrls: [], //  装请求数据的一部分
    videoJson: {
      index: -1,
      dom: null
    },
    page: 2,
    rows: 5,
    hidden: false,
    videoLoading: false
  },
  onLoad: function () {

    var that = this;
       that.getVideosReq();

  },
  getVideosReq: function () {
    var header = {
      'content-type': 'application/x-www-form-urlencoded',
    };
    var that = this;

    wx.request({
      url: app.globalData.url + '/routine/auth_api/getshortvideo?uid=' + app.globalData.uid ,
      data: {
        xiaoben: true,
        page: 1,
        rows: 5
      },
      method: 'GET',
      header: header,
      success: function (res) {

       /* that.data.videos = res.data.data.items;

        for (var i = 0; i < that.data.videos.length; i++) {
          that.playVideo(that.data.videos[i].url, that.data.videos[i].title);
        } */
      
        that.setData({
          videos: res.data.data.items
        });

      }
    });
  },
  onStatePlay: function(e){
     var videoJsonIndex = "videoJson.index";
     var that = this;

         that.setData({
            [videoJsonIndex]: e.currentTarget.dataset.index,
          });
     
  },
  playVideo: function (vid, title) {


    var videoPage = 1;     // 本来全局的
    var pageArr = new Array();   // 本来全局的
    var part_urls = {};  // 本来全局的
    var that = this;
    
    var count = 0;
    var videoArr = [];
    
    if(!that.data.videoLoading){
       that.data.videoLoading = true;
       wx.showLoading({
         title: '视频在解析中',
       });

    };
    
    qqVideo.getVideoes(vid,count,videoArr).then(function (response) {

      for (var i = 1; i < response.length + 1; i++) {
        var indexStr = 'index' + (i)    // 1 到 length
        pageArr.push(i);
        part_urls[indexStr] = response[i - 1];     // 0 到 (length-1)
      };

     // console.log(response);
      wx.hideLoading();

      that.data.videoLoading = false;
      
      //当我们视频超过10分钟时，可以把本来设置在全局的用that.data.videUrls.push,
      //然后在播放结束那里用对应的下标来获取
      that.data.videUrls.push({ url: response[0], title: title });
      that.setData({
        videUrls: that.data.videUrls,
      });
    });

  },
  playStart: function (e) {

    var that = this;
    var eIndex = e.currentTarget.dataset.index;
    var dom = that.data.videoJson.dom;
    var videoJsonIndex = "videoJson.index";
    var videoJsonDom = "videoJson.dom";
     
    if (that.data.videoJson.index == eIndex) return;

    if (dom != null) {
      dom.pause();
    };


    that.setData({
      [videoJsonIndex]: eIndex,
      [videoJsonDom]: wx.createVideoContext(e.currentTarget.id)
    });
  },
  // 因为视频超过10分钟之后，会分段，所以当视频为多段的时候，
  // 自动播放下一段视频
  playEnd: function () {

    /* if (videoPage >= parseInt(pageArr.length)) {
       // part_urls = {};
          videoPage = 1;
       // this.videoContext.exitFullScreen();  //退出全屏方法
     } else {
       videoPage++;
       var index = 'index' + videoPage;
       this.setData({
         videUrl: ''
       });
       this.setData({
         videUrl: part_urls[index]
       });
     }*/
  },
  onReady: function () {
 
    // 页面渲染完成
    // this.videoContext = wx.createVideoContext('myVideo')
  },
  onShow: function () {
    // 页面显示
  },
  onHide: function () {
    // 页面隐藏
    var that = this;
    if (that.data.videoJson.dom != null) {
      that.data.videoJson.dom.pause();
    };

  },
  onUnload: function () {
    // 页面关闭
  },
    /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
    var that = this;
    var limit = that.data.rows;

    if (that.data.hidden || that.data.videoLoading){
      return;
    };

    wx.showLoading({
      title: '加载中'
    });

    var offset = that.data.page++;

    that.setData({
      hidden: true,
    });

    wx.request({
      url: app.globalData.url + '/routine/auth_api/getshortvideo?uid=' + app.globalData.uid ,
      data: {
        xiaoben: true,
        page: offset,
        rows: limit
      },
      method: 'GET',
      success: function (res) {
        wx.hideLoading();
        if (res.data.data.items.length < 1) {
          --that.data.page;
          wx.showToast({
            title: '没有更多的视频了',
            icon: 'none',
            duration: 2000
          })
        } else {
          
          /*that.data.videos = res.data.data.items;

          for (var i = 0; i < that.data.videos.length; i++) {
            that.playVideo(that.data.videos[i].url, that.data.videos[i].title);
          }*/

          that.data.videos = that.data.videos.concat(res.data.data.items);

          that.setData({
             videos: that.data.videos
          });
         
        };

      },
      fail: function (res) {
        console.log('submit fail');
      },
      complete: function (res) {
        that.data.hidden = false;
      }
    })
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})