var app = getApp();

Page({

  /**
   * 页面的初始数据
   */
  data: {
    date: '2019-08-22',
    nowDate: '',
    product_id: -1,
    pro_name: '',
  },
  formSubmit: function (e) {
    var that = this;
     
    var formId = e.detail.formId;
    var name = e.detail.value.name;
    var phone = e.detail.value.phone;
    var date = that.data.date;
    var warn = '';
    var flag = true;

    if (name == '') {
      warn = '请输入预约姓名';
    } else if (!/^1(3|4|5|7|8|9)\d{9}$/i.test(phone)) {
      warn = '你输入的手机号有误';
    } else {
      flag = false;
    };

    if (flag) {
      wx.showModal({
        title: '提示',
        content: warn,
        showCancel: false
      });
    } else {
      var header = {
        'content-type': 'application/x-www-form-urlencoded',
      };
      wx.request({
        url: app.globalData.url + '/routine/auth_api/subscribe?uid=' + app.globalData.uid,
        method: 'POST',
        header: header,
        data: {
          uid: app.globalData.uid,
          name: name,
          phone: phone,
          time: new Date(date).getTime(),
          product_id: that.data.product_id,
          pro_name: that.data.pro_name,
        },
        success: function (res) {
          if(res.data.code == 200){
            wx.showModal({
              title: '提示',
              content: '预约成功',
              showCancel: false,
              success: function () {
                wx.navigateTo({
                  url: '/pages/myMakeAnAppointment/index',
                });
              }
            });
          }else{
            wx.showModal({
              title: '提示',
              content: '预约失败',
              showCancel: false
            });
          };
        }
      });
    };
  },
  bindDateChange: function (e) {
    console.log('picker发送选择改变，携带值为', e.detail.value)
    this.setData({
      date: e.detail.value
    })
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    app.setUserInfo();
    if(app.globalData.uid == null)return;
    
    var that = this;
    var time = new Date().getTime();
    var nowDate = new Date(time + 86400 * 1000).toLocaleDateString().replace(/\//g, '-');
    that.setData({
      date: nowDate,
      nowDate: nowDate,
      product_id: options.store_id,
      pro_name: options.store_name
    });
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})