var app = getApp();
var WxParse = require('../../wxParse/wxParse.js');
var wxh = require('../../utils/wxh.js');
Page({

  /**
   * 页面的初始数据
   */
  data: {
    indicatorDots: true,//是否显示面板指示点;
    autoplay: true,//是否自动播放;
    interval: 3000,//动画间隔的时间;
    duration: 500,//动画播放的时长;
    indicatorColor: "rgba(51, 51, 51, .3)",
    indicatorActivecolor: "#ffffff",
    show_code_flag: 'false',  // 直达店铺or直接购买
    detailsOrComment: 'xq',  // 详情or评论
    collect: false,// 是否收藏
    inputValue: '',   // 评论框值
    userinfo: {}, // 用户信息存放
    productSelect: [
      { image: "" },
      { store_name: "" },
      { price: 0 },
      { unique: "" },
      { stock: 0 },
    ],
    productAttr: [],
    productValue: [],
    attrName: '',
    storeInfo: [],
    id: 0,
    num: 1,
    show: false,
    prostatus: false,
    reply: [],
    replyCount: 0,
    shop_id: 0,
    shop_idGetData: {}
  },
  getShoppingDetails: function () {  // 商品详情信息获取
    var that = this;
    var header = {
      'content-type': 'application/x-www-form-urlencoded',
    };
    wx.request({
      url: app.globalData.url + '/routine/auth_api/details?uid=' + app.globalData.uid,
      method: 'POST',
      data: {
        id: that.data.id
      },
      header: header,
      success: function (res) {
        if (res.data.code == 200) {
          var image = "productSelect.image";
          var store_name = "productSelect.store_name";
          var price = "productSelect.price";
          var unique = "productSelect.unique";
          var stock = "productSelect.stock";
          that.setData({
            storeInfo: res.data.data.storeInfo,
            productAttr: res.data.data.productAttr,
            productValue: res.data.data.productValue,
            collect: res.data.data.storeInfo.userCollect,
            [image]: res.data.data.storeInfo.image,
            [stock]: res.data.data.storeInfo.stock,
            [store_name]: res.data.data.storeInfo.store_name,
            [price]: res.data.data.storeInfo.price,
            [unique]: '',
            reply: res.data.data.reply,
            replyCount: res.data.data.replyCount,
            shop_id: res.data.data.shop_id
          })

          //that.likeDataFun();
          WxParse.wxParse('content', 'html', res.data.data.storeInfo.description, that, 0);

        } else {
          wx.showToast({
            title: res.data.msg,
            icon: 'none',
            duration: 1000
          });

        }
      }
    });
  },
  shopIdGetCode: function (shop_id) {
    var that = this;
    var header = {
      'content-type': 'application/x-www-form-urlencoded',
    };
    wx.request({
      url: app.globalData.url + '/routine/auth_api/getShop?uid=' + app.globalData.uid,
      method: 'POST',
      data: {
        id: shop_id
      },
      header: header,
      success: function (res) {
        if (res.data.code == 200) {

          that.setData({
            shop_idGetData: res.data.data
          });

        } else {
          wx.showToast({
            title: res.data.msg,
            icon: 'none',
            duration: 1000
          });

        }
      }
    });
  },
  shopIdCodePreviewImage: function (e) {
    wx.previewImage({
      current: e.currentTarget.dataset.src,
      urls: [e.currentTarget.dataset.src]
    });
  },
  show_code_flag: function (e) {
    var show = e.currentTarget.dataset.show;
    var that = this;
    if (show == 'true') that.shopIdGetCode(that.data.shop_id);
    that.setData({
      show_code_flag: show
    });
  },
  detailsOrComment: function (e) {
    this.setData({
      detailsOrComment: e.currentTarget.dataset.show
    });
  },
  plInputSubmit: function () {
    wx.showToast({
      title: "123",
      icon: 'none',
      duration: 2000
    });
  },
  plInputGetValue: function (e) {
    this.setData({
      inputValue: e.detail.value
    });
  },
  tapsize: function (e) {
    var that = this;
    var key = e.currentTarget.dataset.key;
    var attrValues = [];
    var attrName = that.data.attrName;
    var attrNameArr = attrName.split(",");
    var array = that.data.productAttr;
    for (var i in that.data.productAttr) {
      for (var j in that.data.productAttr[i]['attr_values']) {
        if (that.data.productAttr[i]['attr_values'][j] == key) {
          attrValues = that.data.productAttr[i]['attr_values'];
        }
      }
    }
    for (var ii in attrNameArr) {
      if (that.in_array(attrNameArr[ii], attrValues)) {
        attrNameArr.splice(ii, 1);
      }
    }
    attrName = attrNameArr.join(',');
    if (attrName) var eName = e.currentTarget.dataset.key + ',' + attrName;
    else var eName = e.currentTarget.dataset.key;
    attrNameArr = eName.split(",");
    var isBool = false;
    var isattrNameArrLength = 0;
    for (var an in attrNameArr) {
      if (attrNameArr[an]) isattrNameArrLength = isattrNameArrLength + 1;
    }
    for (var b in that.data.productValue) {
      var sukValue = that.data.productValue[b].suk.split(",");
      if (sukValue.length == isattrNameArrLength) {
        if (that.in_array_two(attrNameArr, sukValue)) {
          isBool = true;
        }
      } else {
        isBool = true;
      }
    }
    if (!isBool) {
      wx.showToast({
        title: '属性不存在，请重新选择',
        icon: 'none',
        duration: 1500,
      })
    } else {
      that.setData({
        attrName: e.currentTarget.dataset.key + ',' + attrName
      })
      attrNameArr = that.data.attrName.split(",");
      var attrNameArrSort = '';
      for (var jj in that.data.productAttr) {
        for (var jjj in that.data.productAttr[jj]['attr_values']) {
          if (that.in_array(that.data.productAttr[jj]['attr_values'][jjj], attrNameArr)) {
            attrNameArrSort += that.data.productAttr[jj]['attr_values'][jjj] + ',';
          }
        }
      }
      for (var jj in array) {
        for (var jjj in array[jj]['attr_values']) {
          if (that.in_array(array[jj]['attr_values'][jjj], attrNameArr)) {
            array[jj]['attr_value'][jjj].check = true;
          } else {
            array[jj]['attr_value'][jjj].check = false;
          }
        }
      }
      that.setData({
        productAttr: array
      })
      var attrNameArrSortArr = attrNameArrSort.split(",");
      attrNameArrSortArr.pop();
      that.setData({
        attrName: attrNameArrSortArr.join(',')
      })
      var arrAttrName = that.data.attrName.split(",");
      for (var index in that.data.productValue) {
        var strValue = that.data.productValue[index]['suk'];
        var arrValue = strValue.split(",");
        if (that.in_array_two(arrValue, arrAttrName)) {
          var image = "productSelect.image";
          var store_name = "productSelect.store_name";
          var price = "productSelect.price";
          var unique = "productSelect.unique";
          var stock = "productSelect.stock";
          that.setData({
            [image]: that.data.productValue[index]['image'],
            [price]: that.data.productValue[index]['price'],
            [unique]: that.data.productValue[index]['unique'],
            [stock]: that.data.productValue[index]['stock'],
          })
        }
      }
    }
  },
  in_array_two: function (arr1, arr2) {
    if (arr1.sort().toString() == arr2.sort().toString()) {
      return true;
    }
    else {
      return false;
    }

  },
  in_array: function (str, arr) {
    for (var f1 in arr) {
      if (arr[f1] == str) {
        return true;
      }
    }
  },
  bindMinus: function () {
    var that = this;
    wxh.carmin(that)
  },
  bindPlus: function () {
    var that = this;
    wxh.carjia(that);
  },
  setNumber: function (e) {
    var that = this;
    var num = parseInt(e.detail.value);
    that.setData({
      num: num ? num : 1
    })
  },
  goOrder: function () {
    this.setData({
      prostatus: true,
      show: true
    });
  },
  subBuy: function () {
    var that = this;
    var header = {
      'content-type': 'application/x-www-form-urlencoded',
    };
    wx.request({
      url: app.globalData.url + '/routine/auth_api/now_buy?uid=' + app.globalData.uid,
      method: 'GET',
      data: {
        productId: that.data.id,
        cartNum: that.data.num,
        uniqueId: that.data.productSelect.unique
      },
      header: header,
      success: function (res) {
        if (res.data.code == 200) {
          wx.navigateTo({ //跳转至指定页面并关闭其他打开的所有页面（这个最好用在返回至首页的的时候）
            url: '/pages/order-confirm/order-confirm?id=' + res.data.data.cartId
          })
        } else {
          wx.showToast({
            title: res.data.msg,
            icon: 'none',
            duration: 2000
          })
        }
      }
    });
  },
  modelbg: function (e) {
    this.setData({
      prostatus: false,
      show: false
    })
  },
  setCollect: function () {
    if (this.data.collect) this.unCollectProduct();
    else this.collectProduct();
  },
  unCollectProduct: function () {
    var that = this;
    var header = {
      'content-type': 'application/x-www-form-urlencoded',
    };
    wx.request({
      url: app.globalData.url + '/routine/auth_api/uncollect_product?uid=' + app.globalData.uid,
      method: 'POST',
      header: header,
      data: {
        productId: that.data.id
      },
      success: function (res) {
        wx.showToast({
          title: '取消收藏成功',
          icon: 'success',
          duration: 1500,
        })
        that.setData({
          collect: false,
        })
      }
    })
  },
  collectProduct: function () {
    var that = this;
    var header = {
      'content-type': 'application/x-www-form-urlencoded',
    };
    wx.request({
      url: app.globalData.url + '/routine/auth_api/collect_product?uid=' + app.globalData.uid,
      method: 'POST',
      header: header,
      data: {
        productId: that.data.id,
        store_name: that.data.productSelect.store_name,
        price: that.data.productSelect.price
      },
      success: function (res) {
        wx.showToast({
          title: '收藏成功',
          icon: 'success',
          duration: 1500,
        })
        that.setData({
          collect: true,
        })
      }
    })
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var that = this;
    //app.globalData.openPages = '/pages/businessSpecialShopping_details/index?id=' + options.id || 0;
    app.setUserInfo();
    if (!app.globalData.uid) return;
    var store_id = 0;
    if (options.id) {
      store_id = options.id;
    };
    that.setData({
      id: store_id
    });
    that.getShoppingDetails();
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    /*var header = {
      'content-type': 'application/x-www-form-urlencoded',
    };
    var that = this;
    wx.request({
      url: app.globalData.url + '/routine/auth_api/my?uid=' + app.globalData.uid,
      method: 'POST',
      header: header,
      success: function (res) {
        that.setData({
          userinfo: res.data.data,
        })
      }
    });*/
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
    /*wx.reLaunch({
      url: '/pages/businessSpecial/index'
    })*/

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})