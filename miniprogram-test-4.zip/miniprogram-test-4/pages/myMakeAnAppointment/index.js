var app = getApp();

Page({

  /**
   * 页面的初始数据
   */
  data: {
     makeAnAppointmentData: [],
     hidden: false,
     offset: 2,
     makeAnAppointmentDataFlag: 0
  },
  stay: function() {
    var that = this;
        that.setData({
          makeAnAppointmentDataFlag: 0,
          makeAnAppointmentData: []
        });
        that.makeAnAppointmentDataReq(0);
  },
  over: function(){
    var that = this;
    that.setData({
      makeAnAppointmentDataFlag: 1,
      makeAnAppointmentData: []
    });
    that.makeAnAppointmentDataReq(1);
  },
  already: function() {
    var that = this;
        that.setData({
          makeAnAppointmentDataFlag: 2,
          makeAnAppointmentData: []
        });
        that.makeAnAppointmentDataReq(2);
  },
  makeAnAppointmentDataReq: function(status) {
    var header = {
      'content-type': 'application/x-www-form-urlencoded',
    };
    var that = this;
    wx.request({
      url: app.globalData.url + '/routine/auth_api/getsubscribe?uid=' + app.globalData.uid,
      method: 'GET',
      data: {
        page: 1,
        rows: 10,
        is_show: status
      },
      header: header,
      success: function (res) {
        var data = res.data.data.items;
        for (var i = 0; i < data.length; i++) {
          data[i].time = new Date(data[i].time * 1).toLocaleDateString().replace(/\//g, '-');
        };
        that.setData({
          makeAnAppointmentData: data
        });
      }
    });
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    app.setUserInfo();
    if (app.globalData.uid == null) return;
    this.makeAnAppointmentDataReq(0);
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
    var that = this;

    if (that.data.hidden) return;

    var offset = that.data.offset++;

    that.setData({
      hidden: true,
    });

    wx.request({
      url: app.globalData.url + '/routine/auth_api/getsubscribe?uid=' + app.globalData.uid,
      method: 'GET',
      data: {
        page: offset,
        rows: 10
      },
      success: function (res) {
        if (res.data.data.items.length < 1) {
          --that.data.offset;
          wx.showToast({
            title: '预约信息获取已到尽头',
            icon: 'none',
            duration: 2000
          })
        } else {
         var data = res.data.data.items;
          for (var i = 0; i < data.length; i++) {
            data[i].time = new Date(data[i].time * 1).toLocaleDateString().replace(/\//g, '-');
          };

          that.data.makeAnAppointmentData = that.data.makeAnAppointmentData.concat(data);
        };
        that.setData({
          hidden: false,
          makeAnAppointmentData: that.data.makeAnAppointmentData
        });
      },
      fail: function (res) {
        console.log('submit fail');
      },
      complete: function (res) {
        console.log('submit complete');
      }
    })
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})