//app.js
App({
  onLaunch: function () {
    //  腾讯云live start
    const { model, system, statusBarHeight } = wx.getSystemInfoSync();
    var headHeight;
    if (/iphone\s{0,}x/i.test(model)) {
      headHeight = 88;
    } else if (system.indexOf('Android') !== -1) {
      headHeight = 68;
    } else {
      headHeight = 64;
    }
    this.globalData.headerHeight = headHeight;
    this.globalData.statusBarHeight = statusBarHeight;
    //  腾讯云live end
  },
  globalData: {
    url: 'https://live.largehill.net',  // 数据请求前缀
    imgUrl: '',      // 图片请求前缀
    uid: null,
    openid: '',
    openPages: '',
    spid: 0,
    city: '',      //  用户手机号对应归属地
    phone: null,   //  用户手机号
    openMobileLocStatus: 1,  //  用户归属地验证是否开启 1为开启 0为关闭
    //  腾讯云live
    userInfo: null,
    headerHeight: 0,
    statusBarHeight: 0
  },
  setBarColor: function () {
    var that = this;

    wx.setNavigationBarColor({
      frontColor: '#000000',
      backgroundColor: '#red',
    })
  },
  setUserInfo: function () {
    var that = this;
    if (that.globalData.uid == null) {//是否存在用户信息，如果不存在跳转到首页
      wx.showToast({
        title: '需要先登录',
        icon: 'none',
        duration: 1500,
      })
      setTimeout(function () {
        wx.switchTab({
          url: '/pages/user/index',
        })
      }, 1500)
    }
  },
})