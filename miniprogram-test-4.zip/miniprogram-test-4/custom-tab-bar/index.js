Component({
  options: {
    addGlobalClass: true,
  },
  data: {
    selected: 0,
    list: [{
      pagePath: "/pages/basics/home/home",
      iconPath: "/images/tabbar/1-2.png",
      selectedIconPath: "/images/tabbar/1-2.png",
      text: "广告发布"
    },
    {
      pagePath: "/pages/component/home/home",
      iconPath: "/images/tabbar/component.png",
      selectedIconPath: "/images/tabbar/component_cur.png",
      text: "商家特价"
    },
    {
      pagePath: "/pages/plugin/home/home",
      iconPath: "/images/tabbar/plugin.png",
      selectedIconPath: "/images/tabbar/plugin_cur.png",
      text: "资讯互动"
    },
    {
      pagePath: "/pages/user/index",
      iconPath: "/images/tabbar/4-1.png",
      selectedIconPath: "/images/tabbar/4-2.png",
      text: "我的"
    }
    ]
  },
  methods: {
    switchTab(e) {
      const url = e.currentTarget.dataset.path
      wx.switchTab({
        url
      })
    }
  },
  pageLifetimes: {
  },
})